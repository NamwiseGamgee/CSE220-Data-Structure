public class Node
{
  int elem;
  Node next;
  public Node (int element, Node next)
  {
    this.elem = element;
    this.next = next;
  }
}