public class Node {
  int elem;
  Node next;
  public Node(int e,Node n) {
    elem=e;
    next=n;
  }
}